# CART3R Chess Review (Android)

A small Android Studio starter project for reviewing chess positions after a game,
studying openings, and analysing puzzles.

## What it does
- Accepts a FEN position manually.
- Performs basic FEN structure validation.
- Opens that position in Lichess Analysis in the browser.

## What it deliberately does not do
- Read or capture Chess.com screens.
- Float over live games to recommend moves.
- Automate moves or provide covert assistance in rated games.

## Build
1. Install Android Studio.
2. Open this folder as an existing Gradle project.
3. Let Gradle sync.
4. Connect an Android device with USB debugging enabled, or use an emulator.
5. Select Run.

The project uses Android SDK 35 and a minimum Android version of API 23,
so Android 12 is supported.
