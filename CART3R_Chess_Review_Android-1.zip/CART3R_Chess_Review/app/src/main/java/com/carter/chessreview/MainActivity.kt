package com.carter.chessreview

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 8, 10)
    private val panel = Color.rgb(24, 13, 15)
    private lateinit var fenInput: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 32, 24, 24)
            setBackgroundColor(bg)
        }
        val title = TextView(this).apply {
            text = "CART3R  /  CHESS REVIEW"
            textSize = 22f
            setTextColor(Color.rgb(255, 70, 70))
        }
        val subtitle = TextView(this).apply {
            text = "POST-GAME POSITION ANALYSIS"
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, 8, 0, 24)
        }
        fenInput = EditText(this).apply {
            hint = "Paste a FEN position here"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding(14, 14, 14, 14)
            setBackgroundColor(panel)
            minLines = 3
            gravity = Gravity.TOP
        }
        val analyze = Button(this).apply {
            text = "OPEN POSITION ANALYSIS"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(150, 25, 35))
            setOnClickListener { openAnalysis() }
        }
        val start = Button(this).apply {
            text = "LOAD STANDARD START POSITION"
            setOnClickListener {
                fenInput.setText("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1")
                status.text = "Starting position loaded."
            }
        }
        status = TextView(this).apply {
            text = "Paste a FEN from a completed game or a study position."
            setTextColor(Color.LTGRAY)
            textSize = 13f
            setPadding(0, 18, 0, 0)
        }
        val note = TextView(this).apply {
            text = "\nThis companion is for puzzles, studies and completed-game review. It does not read Chess.com screens or provide hidden assistance during live games."
            setTextColor(Color.GRAY)
            textSize = 12f
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(fenInput, LinearLayout.LayoutParams(-1, 130))
        root.addView(analyze, LinearLayout.LayoutParams(-1, 56).apply { topMargin = 16 })
        root.addView(start, LinearLayout.LayoutParams(-1, 52).apply { topMargin = 8 })
        root.addView(status)
        root.addView(note)
        setContentView(root)
    }

    private fun openAnalysis() {
        val fen = fenInput.text.toString().trim()
        if (!isPlausibleFen(fen)) {
            status.text = "That FEN doesn't look valid. Check that it has 6 fields and 8 board ranks."
            return
        }
        val uri = Uri.parse("https://lichess.org/analysis/" + Uri.encode(fen))
        startActivity(Intent(Intent.ACTION_VIEW, uri))
        status.text = "Opening the position in Lichess analysis."
    }

    private fun isPlausibleFen(fen: String): Boolean {
        val fields = fen.split(Regex("\\s+"))
        if (fields.size != 6) return false
        val ranks = fields[0].split("/")
        if (ranks.size != 8) return false
        val validPieces = "prnbqkPRNBQK"
        for (rank in ranks) {
            var count = 0
            for (ch in rank) {
                if (ch in '1'..'8') count += ch.digitToInt()
                else if (ch in validPieces) count++
                else return false
            }
            if (count != 8) return false
        }
        return fields[1] in listOf("w", "b") &&
            fields[2].matches(Regex("^(K?Q?k?q?|-)${'$'}")) &&
            fields[3].matches(Regex("^(-|[a-h][36])${'$'}"))
    }
}
